// /verify.tsx — Veritas Capsule Hash Verification Tool
import { useState } from "react";

export default function CapsuleVerifier() {
  const [hash, setHash] = useState("");
  const [result, setResult] = useState(null);

  async function handleVerify() {
    const res = await fetch(`/api/verify-capsule?hash=${encodeURIComponent(hash)}`);
    const data = await res.json();
    setResult(data);
  }

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold mb-4">🔐 Veritas Capsule Verifier</h1>
      <input
        type="text"
        placeholder="Enter capsule hash or Veritas ID..."
        className="border p-2 rounded w-full max-w-md"
        value={hash}
        onChange={(e) => setHash(e.target.value)}
      />
      <button onClick={handleVerify} className="mt-3 px-4 py-2 bg-indigo-600 text-white rounded">Verify</button>
      {result && (
        <div className="mt-6 border p-4 rounded bg-gray-100">
          <p><strong>Status:</strong> {result.status}</p>
          {result.capsuleId && <p><strong>Capsule ID:</strong> {result.capsuleId}</p>}
          {result.timestamp && <p><strong>Timestamp:</strong> {result.timestamp}</p>}
        </div>
      )}
    </div>
  );
}
