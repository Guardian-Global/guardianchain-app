# GuardianChain Revenue Transparency

GuardianChain is committed to full transparency, DAO oversight, and fair creator monetization.

## 📘 Revenue Model Explainers

- [Download Full Explainer Deck (PDF)](GuardianChain_Revenue_Explainer_Deck_Charted.pdf)
- [1-Page Summary](GuardianChain_Revenue_Share_Summary.pdf)

## 📜 Overview

GuardianChain splits revenue and yield fairly across creators, DAO treasury, and the platform:

- Capsule Mint: **70% Creator / 20% DAO / 10% Platform**
- Capsule Unlock: **50% Creator / 25% Referrer / 25% DAO**
- GTT Yield: **90% Creator / 10% DAO Reserve**
- Gated Content: **60% Creator / 30% Platform / 10% DAO**

### Compliance

- GTT requires active participation — it is not passive income.
- DAO treasury is public and auditable.
- Full KYC tiers supported for global compliance.

_Last updated: August 2025_  
_Contact: compliance@guardianchain.app_
