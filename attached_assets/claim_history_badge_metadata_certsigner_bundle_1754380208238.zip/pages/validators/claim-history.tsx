import { useEffect, useState } from "react";

export default function ClaimHistory() {
  const [claims, setClaims] = useState([]);

  useEffect(() => {
    fetch("/api/validators/claims").then(res => res.json()).then(setClaims);
  }, []);

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-xl font-bold mb-4">📜 Validator Claim History</h1>
      <ul className="space-y-3 text-sm">
        {claims.map((c, i) => (
          <li key={i} className="border p-3 rounded shadow-sm bg-white">
            <strong>Capsule:</strong> {c.capsuleId}<br />
            <strong>Timestamp:</strong> {new Date(c.timestamp).toLocaleString()}<br />
            GTT Claimed: {c.amount}
          </li>
        ))}
      </ul>
    </div>
  );
}
