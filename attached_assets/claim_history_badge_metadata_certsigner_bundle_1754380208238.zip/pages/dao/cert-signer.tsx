import { useState } from "react";

export default function CertSigner() {
  const [capsuleId, setCapsuleId] = useState("");
  const [signed, setSigned] = useState(false);

  const handleSign = async () => {
    const res = await fetch("/api/dao/sign-cert", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ capsuleId })
    });
    const data = await res.json();
    setSigned(data.success);
  };

  return (
    <div className="p-6 max-w-lg mx-auto">
      <h1 className="text-xl font-bold mb-4">🖊️ DAO Certificate Signer</h1>
      <input
        type="text"
        placeholder="Capsule ID"
        value={capsuleId}
        onChange={(e) => setCapsuleId(e.target.value)}
        className="p-2 border rounded w-full mb-2"
      />
      <button onClick={handleSign} className="px-4 py-2 bg-green-600 text-white rounded">
        Sign Certificate
      </button>
      {signed && <p className="text-green-500 mt-2">✅ Certificate signed on-chain.</p>}
    </div>
  );
}
