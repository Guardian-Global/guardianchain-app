export default function handler(req, res) {
  const { capsuleId } = req.body;
  console.log("Certificate signed for capsule:", capsuleId);
  res.status(200).json({ success: true });
}
