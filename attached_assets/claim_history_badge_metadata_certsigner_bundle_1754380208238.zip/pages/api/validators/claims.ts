export default function handler(_, res) {
  res.status(200).json([
    { capsuleId: "capsule-101", timestamp: 1722890000000, amount: 15 },
    { capsuleId: "capsule-102", timestamp: 1722900000000, amount: 22 }
  ]);
}
