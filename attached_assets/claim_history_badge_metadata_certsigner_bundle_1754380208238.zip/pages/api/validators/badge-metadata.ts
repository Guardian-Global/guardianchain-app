export default function handler(_, res) {
  res.status(200).json({
    name: "Guardian Validator Badge",
    description: "Awarded to top validators for capsule verification and truth protection.",
    image: "https://guardianchain.app/images/badge-nft.png",
    attributes: [
      { trait_type: "Tier", value: "Gold" },
      { trait_type: "Capsules Verified", value: 108 },
      { trait_type: "DAO Reputation Score", value: 172 }
    ]
  });
}
