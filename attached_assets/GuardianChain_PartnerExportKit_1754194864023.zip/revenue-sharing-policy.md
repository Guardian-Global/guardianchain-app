# GuardianChain Revenue Sharing Policy

GuardianChain is committed to full transparency and global compliance in our creator and protocol revenue-sharing systems.

## 🔹 Capsule Minting
- 70% – Creator
- 20% – DAO Treasury
- 10% – Platform (infrastructure & ops)

## 🔓 Capsule Unlock Fees
- 50% – Original Creator
- 25% – Referrer (if applicable)
- 25% – DAO Treasury

## 💰 GTT Yield Rewards
- 90% – Creator (verified authorship + time lock)
- 10% – DAO Reserve

## 📦 Gated Content / Subscriptions
- 60% – Creator
- 30% – Platform
- 10% – DAO Treasury

## 🧾 Storage Tiers (Vault)
Storage costs are transparently marked up by 25% for sovereign vault hosting. All fees go directly to platform infrastructure.

## 🔐 Legal & Compliance Notes
- All revenue is earned through participation; GTT is not a passive token.
- Terms of Revenue Sharing Agreement accepted during onboarding.
- GuardianChain supports KYC tiers for compliant fiat off-ramps.

_Contact: compliance@guardianchain.app_  
_Updated: August 2025_
