# GTT Tokenomics (Updated 2025)

## 🔢 Total Supply: 1,000,000,000 GTT

## 📊 Crosschain Distribution
- **Polygon**: 600,000,000 GTT (legacy + capsule markets)
- **Base**: 400,000,000 GTT (grief yield, validator node unlocks, DAO)
- Full interoperability via canonical bridge and mint/burn sync

## 🧑‍🚀 Founder Allocation (Troy Cronin)
- 18% reserved = 180,000,000 GTT
- **5% unlocked at TGE**, remainder over 4 years (1-year cliff)

## ⛓ Vesting Principles
- Cliff-based vesting for team + advisors
- Emissions for yield pools
- DAO-controlled unlocks for ecosystem

## 🏛 Legal + Investor Friendly
- Founder does not hold majority
- Multi-chain reserves for flexibility
- Proof of Work (capsules) integrated with Proof of Time (vesting)

This structure allows for sustainable growth, responsible governance, and strategic flexibility across Base + Polygon.
