
"use client";

import { Dialog } from "@headlessui/react";
import { motion } from "framer-motion";
import { useRouter } from "next/router";
import { useWallet } from "@/hooks/useWallet";
import { useState } from "react";

const routes = [
  { name: "Dashboard", href: "/dashboard", emoji: "🏠" },
  { name: "Create Capsule", href: "/create", emoji: "➕" },
  { name: "My Capsules", href: "/capsules", emoji: "📦" },
  { name: "Vault", href: "/vault", emoji: "💰" },
  { name: "Profile", href: "/profile", emoji: "👤" },
  { name: "Timeline", href: "/timeline", emoji: "🕰️" },
  { name: "Lineage", href: "/lineage", emoji: "🧬" },
  { name: "Explore", href: "/explore", emoji: "🌍" },
  { name: "Settings", href: "/settings", emoji: "⚙️" },
  { name: "Admin", href: "/admin", emoji: "🛠️" }
];

export default function EnhancedMegaNavigation() {
  const { address } = useWallet();
  const router = useRouter();
  const [isOpen, setIsOpen] = useState(true);
  const [query, setQuery] = useState("");

  const filteredRoutes = routes.filter((r) =>
    r.name.toLowerCase().includes(query.toLowerCase())
  );

  return (
    <Dialog open={isOpen} onClose={() => setIsOpen(false)} className="fixed inset-0 z-50 flex items-center justify-center">
      <div className="fixed inset-0 bg-black/50 backdrop-blur-sm" aria-hidden="true" />

      <Dialog.Panel as={motion.div} initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0, scale: 0.95 }} className="relative mx-auto w-full max-w-3xl p-6 rounded-2xl bg-white/10 shadow-xl ring-1 ring-white/20">
        <h2 className="text-2xl font-semibold text-purple-200">GuardianChain Navigation</h2>
        <p className="text-sm text-gray-300 mb-4">Explore the truth preservation ecosystem</p>

        <input
          type="text"
          placeholder="Search..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          className="w-full mb-4 p-2 rounded bg-white/10 text-white placeholder-gray-400 border border-white/10"
        />

        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {filteredRoutes.map((route) => (
            <button key={route.href} onClick={() => router.push(route.href)} className="bg-white/5 hover:bg-white/10 rounded-xl p-4 flex flex-col items-start border border-white/10">
              <span className="text-2xl">{route.emoji}</span>
              <span className="text-sm mt-2 text-white">{route.name}</span>
            </button>
          ))}
        </div>

        <div className="mt-6 text-sm text-gray-400">Connected: {address?.slice(0, 6)}...{address?.slice(-4)}</div>
      </Dialog.Panel>
    </Dialog>
  );
}
