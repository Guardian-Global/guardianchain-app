// /api/search-capsules.ts — capsule search + map API
import { createClient } from "@supabase/supabase-js";
import type { NextApiRequest, NextApiResponse } from "next";

const supabase = createClient(
  process.env.NEXT_PUBLIC_SUPABASE_URL!,
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!
);

export default async function handler(req: NextApiRequest, res: NextApiResponse) {
  const { query, map } = req.query;

  if (map === "true") {
    const { data, error } = await supabase
      .from("capsules")
      .select("id, grief_tier, influence_score, created_at")
      .limit(100);

    if (error) return res.status(500).json({ error });

    const results = data.map((c, i) => ({
      id: c.id,
      grief_tier: c.grief_tier,
      influence_score: c.influence_score || 0,
      x: i,
    }));

    return res.status(200).json({ results });
  }

  const keyword = (query as string)?.toLowerCase() || "";
  const { data, error } = await supabase
    .from("capsules")
    .select("id, grief_tier, tags")
    .or(`tags.ilike.%${keyword}%,content.ilike.%${keyword}%`)
    .limit(20);

  if (error) return res.status(500).json({ error });

  return res.status(200).json({ results: data });
}
