// TruthClusterMap.tsx — interactive grief cluster visualization
import { useEffect, useState } from "react";
import { ResponsiveContainer, ScatterChart, Scatter, XAxis, YAxis, Tooltip, ZAxis } from "recharts";

export default function TruthClusterMap() {
  const [data, setData] = useState([]);

  useEffect(() => {
    fetch("/api/search-capsules?map=true")
      .then((res) => res.json())
      .then((d) => setData(d.results || []));
  }, []);

  return (
    <div className="mt-12">
      <h2 className="text-xl font-semibold mb-4">🗺 TruthCluster: Grief Tier Map</h2>
      <ResponsiveContainer width="100%" height={400}>
        <ScatterChart>
          <XAxis type="number" dataKey="x" name="Time" />
          <YAxis type="number" dataKey="grief_tier" name="Grief Tier" />
          <ZAxis type="number" dataKey="influence_score" range={[60, 400]} name="Influence" />
          <Tooltip cursor={{ strokeDasharray: "3 3" }} />
          <Scatter name="Capsules" data={data} fill="#8884d8" />
        </ScatterChart>
      </ResponsiveContainer>
    </div>
  );
}
