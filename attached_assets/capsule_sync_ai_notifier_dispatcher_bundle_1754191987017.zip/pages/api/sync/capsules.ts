export default function handler(_, res) {
  const syncedCapsules = [
    { id: "cap123", title: "Letter from Mom", chain: "Polygon" },
    { id: "cap456", title: "Healing on Base", chain: "Base" }
  ];
  res.status(200).json(syncedCapsules);
}
