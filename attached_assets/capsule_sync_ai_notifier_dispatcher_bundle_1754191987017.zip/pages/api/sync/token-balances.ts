export default async function handler(req, res) {
  const { wallet } = req.query;
  const balances = {
    polygon: "392,000",
    base: "180,000"
  };
  res.status(200).json({ wallet, balances });
}
