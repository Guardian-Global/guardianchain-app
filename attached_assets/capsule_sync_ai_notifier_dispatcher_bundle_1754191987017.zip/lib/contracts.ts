export function getContractByChain(chainId, type) {
  const addresses = {
    137: {
      capsule: process.env.POLYGON_CONTRACT_CLAIM,
      gtt: process.env.POLYGON_CONTRACT_GTT
    },
    8453: {
      capsule: process.env.BASE_CONTRACT_CLAIM,
      gtt: process.env.BASE_CONTRACT_GTT
    }
  };
  return addresses[chainId]?.[type] || null;
}
