import { ethers } from "ethers";
import { getContractByChain } from "./contracts";

export async function mintGTTCapsule(chainId, { recipient, griefScore, ipfsURI }) {
  const providerUrl = chainId === 8453 ? process.env.BASE_RPC : process.env.POLYGON_RPC;
  const contractAddress = getContractByChain(chainId, "capsule");
  const abi = [ "function mintCapsule(address to, string memory uri, uint256 griefScore) public" ];

  const provider = new ethers.JsonRpcProvider(providerUrl);
  const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);
  const contract = new ethers.Contract(contractAddress, abi, wallet);

  const tx = await contract.mintCapsule(recipient, ipfsURI, griefScore);
  return await tx.wait();
}
