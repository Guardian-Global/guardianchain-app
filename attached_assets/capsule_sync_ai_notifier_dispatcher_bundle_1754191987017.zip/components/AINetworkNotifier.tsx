import { useEffect, useState } from "react";

export default function AINetworkNotifier({ chainId }) {
  const [note, setNote] = useState("");

  useEffect(() => {
    if (chainId === 137) {
      setNote("You're minting on Polygon: High liquidity + yield history.");
    } else if (chainId === 8453) {
      setNote("You're minting on Base: Lower fees + griefScore rewards.");
    }
  }, [chainId]);

  return note ? (
    <p className="text-sm text-blue-600 font-medium my-2">🤖 {note}</p>
  ) : null;
}
