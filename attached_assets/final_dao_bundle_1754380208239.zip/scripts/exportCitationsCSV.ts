import fs from "fs";
import { Parser } from "json2csv";

const citations = [
  {
    capsuleId: "capsule-001",
    author: "Guardian001",
    griefScore: 8,
    timestamp: "2025-08-01",
    citation: "\"capsule-001\" by Guardian001, sealed on Aug 1, 2025 (GriefScore: 8)"
  },
  {
    capsuleId: "capsule-024",
    author: "NodeAlpha",
    griefScore: 9,
    timestamp: "2025-07-22",
    citation: "\"capsule-024\" by NodeAlpha, sealed on Jul 22, 2025 (GriefScore: 9)"
  }
];

const parser = new Parser();
const csv = parser.parse(citations);
fs.writeFileSync("citations.csv", csv);
console.log("✅ citations.csv exported.");
