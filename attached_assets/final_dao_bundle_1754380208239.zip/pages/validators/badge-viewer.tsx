import { useEffect, useState } from "react";

export default function BadgeViewer() {
  const [badges, setBadges] = useState([]);

  useEffect(() => {
    fetch("/api/validators/badges").then(res => res.json()).then(setBadges);
  }, []);

  return (
    <div className="p-6 max-w-3xl mx-auto">
      <h1 className="text-xl font-bold mb-4">🎖 Validator Badge Viewer</h1>
      <ul className="text-sm space-y-3">
        {badges.map((b, i) => (
          <li key={i} className="border p-3 rounded shadow-sm bg-white">
            Wallet: {b.wallet} <br />
            NFT ID: <strong>{b.badgeId}</strong>
          </li>
        ))}
      </ul>
    </div>
  );
}
