import { useEffect, useState } from "react";

export default function EarningsLeaderboard() {
  const [leaders, setLeaders] = useState([]);

  useEffect(() => {
    fetch("/api/dao/earnings").then(res => res.json()).then(setLeaders);
  }, []);

  return (
    <div className="p-6 max-w-4xl mx-auto">
      <h1 className="text-xl font-bold mb-4">🏅 Validator Earnings Leaderboard</h1>
      <ol className="list-decimal ml-6 text-sm space-y-2">
        {leaders.map((v, i) => (
          <li key={i}>
            <strong>{v.name}</strong> — {v.gtt} GTT earned from {v.capsules} capsules
          </li>
        ))}
      </ol>
    </div>
  );
}
