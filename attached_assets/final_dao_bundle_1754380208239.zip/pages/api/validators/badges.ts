export default function handler(_, res) {
  res.status(200).json([
    { wallet: "0xA1b2...eD34", badgeId: "badge-ed34" },
    { wallet: "0xF8a3...9C12", badgeId: "badge-9c12" }
  ]);
}
