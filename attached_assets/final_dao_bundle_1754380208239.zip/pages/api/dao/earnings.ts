export default function handler(_, res) {
  res.status(200).json([
    { name: "NodeAlpha", gtt: 720, capsules: 108 },
    { name: "TruthSentinel", gtt: 665, capsules: 96 },
    { name: "WitnessWolf", gtt: 530, capsules: 82 }
  ]);
}
