// Layout.tsx — App Layout with Sidebar + Topbar + Walkthrough
import Topbar from "./Topbar";
import NavSidebar from "./NavSidebar";
import WalkthroughModal from "./WalkthroughModal";

export default function Layout({ children }) {
  return (
    <div className="flex">
      <NavSidebar />
      <main className="flex-1 min-h-screen bg-gray-50">
        <Topbar />
        <div className="p-6">{children}</div>
      </main>
      <WalkthroughModal />
    </div>
  );
}
