import { ethers } from "ethers";
import fs from "fs";

// GTT ERC20 contract ABI
const abi = JSON.parse(fs.readFileSync("./abi/GTT.json", "utf-8"));
const bytecode = fs.readFileSync("./bytecode/GTT.bin", "utf-8");

async function main() {
  const provider = new ethers.JsonRpcProvider(process.env.BASE_RPC);
  const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);
  console.log("🚀 Deploying from wallet:", wallet.address);

  const factory = new ethers.ContractFactory(abi, bytecode, wallet);
  const contract = await factory.deploy("Guardian Truth Token", "GTT", 18, ethers.parseEther("1000000000"));
  console.log("✅ GTT deployed at:", contract.target);

  await contract.waitForDeployment();
}

main().catch(console.error);
