import { useState, useEffect } from "react";

export default function ChainSwitcher({ onChainChange }) {
  const [chain, setChain] = useState("polygon");

  useEffect(() => {
    if (onChainChange) onChainChange(chain);
  }, [chain]);

  return (
    <div className="mb-4">
      <label className="block text-sm font-medium">🌐 Select Network</label>
      <select
        value={chain}
        onChange={(e) => setChain(e.target.value)}
        className="p-2 border rounded w-full"
      >
        <option value="polygon">Polygon</option>
        <option value="base">Base</option>
      </select>
    </div>
  );
}
