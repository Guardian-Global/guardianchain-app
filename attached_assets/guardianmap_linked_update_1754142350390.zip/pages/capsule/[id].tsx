// [id].tsx — Capsule detail page with GuardianMap links
import { useRouter } from "next/router";
import Link from "next/link";

export default function CapsuleDetailPage() {
  const router = useRouter();
  const { id } = router.query;
  const capsule = { id, parentId: "abc123" }; // mock capsule data

  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Capsule {id}</h1>
      <p className="mt-2 text-gray-700">Capsule content and metadata shown here.</p>
      <div className="mt-4 space-x-4">
        <Link href={`/guardianmap?highlight=${id}`} className="btn btn-secondary">🔎 View in GuardianMap</Link>
        <Link href={`/guardianmap?focus=${capsule.parentId}`} className="text-blue-600 text-sm">⛓ View Truth Lineage</Link>
      </div>
    </div>
  );
}
