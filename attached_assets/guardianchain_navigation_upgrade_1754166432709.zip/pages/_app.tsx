// Injects global layout with MegaSidebar + Walkthrough context
