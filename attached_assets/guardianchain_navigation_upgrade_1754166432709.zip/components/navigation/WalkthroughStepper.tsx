// WalkthroughStepper.tsx — guides users through capsule creation, eternal contracts, and yield setup
