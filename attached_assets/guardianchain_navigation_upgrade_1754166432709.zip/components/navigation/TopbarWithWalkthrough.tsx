// TopbarWithWalkthrough.tsx — includes command menu, onboarding steps
