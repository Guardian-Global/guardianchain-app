// MegaSidebar.tsx — collapsible, nested, mobile-responsive with role-aware routing
