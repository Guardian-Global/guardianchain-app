// MobileDrawer.tsx — adaptive nav for phones + tablets
