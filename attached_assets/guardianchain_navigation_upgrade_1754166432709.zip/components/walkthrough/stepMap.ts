// stepMap.ts — defines steps for /create, /eternal-contracts, /dashboard/yield
