// StepWrapper.tsx — wraps key pages and triggers context steps
