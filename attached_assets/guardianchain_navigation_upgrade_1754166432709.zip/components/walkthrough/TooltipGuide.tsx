// TooltipGuide.tsx — multilingual tooltips using i18n + step context
