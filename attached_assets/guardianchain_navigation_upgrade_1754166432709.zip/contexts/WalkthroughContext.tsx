// Walkthrough context for onboarding progression and status
