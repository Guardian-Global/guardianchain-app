// ROUTES.ts — central config with roles, paths, labels, icons
